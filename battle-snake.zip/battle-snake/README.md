# BattleSnake
A two player twist on the classic game 'snake', written in pure javascript.

<img src='http://i.giphy.com/l0HlLDBzsculjU0vK.gif' width="1200" />
